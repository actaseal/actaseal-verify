ActaSeal tenant export.

events.ndjson     your ledger events, each with a Merkle inclusion proof into the sealed ledger root
receipts.ndjson   your signed receipts
keys.json         the public keys those receipts verify under
seal.json         a signature over the ledger root and the digests of the files above
verify_tenant_export.py   checks all of it offline; needs Python 3 and the cryptography package

Run:  python verify_tenant_export.py <this archive>.zip --public-key <the operator's published key>
Pinning the key shows who sealed it; without it the check only shows the archive is consistent.
